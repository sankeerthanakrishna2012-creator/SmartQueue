from flask import Flask, request, redirect, url_for, session, jsonify, render_template_string
import sqlite3
from datetime import datetime, date, timedelta
from functools import wraps

# ============================================================
# SMART QUEUE - SINGLE FILE FLASK APPLICATION
# ============================================================

app = Flask(__name__)
app.secret_key = "smartqueue_demo_secret_key_2026"

DB_NAME = "smartqueue.db"

# ============================================================
# DOCTORS
# ============================================================

DOCTORS = [
    {
        "name": "Dr. Ravi Kumar",
        "specialist": "Cardiologist",
        "full": "Dr. Ravi Kumar - Cardiologist",
        "service_time": 12
    },
    {
        "name": "Dr. Priya Sharma",
        "specialist": "General Physician",
        "full": "Dr. Priya Sharma - General Physician",
        "service_time": 8
    },
    {
        "name": "Dr. Arjun Reddy",
        "specialist": "Dermatologist",
        "full": "Dr. Arjun Reddy - Dermatologist",
        "service_time": 10
    }
]

TIME_SLOTS = [
    "10:00 AM",
    "10:30 AM",
    "11:00 AM",
    "11:30 AM",
    "12:00 PM",
    "02:00 PM",
    "02:30 PM",
    "03:00 PM",
    "03:30 PM",
    "04:00 PM"
]


# ============================================================
# DATABASE
# ============================================================

def db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():

    conn = db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER NOT NULL,
            gender TEXT NOT NULL,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            age INTEGER NOT NULL,
            gender TEXT NOT NULL,
            doctor TEXT NOT NULL,
            specialist TEXT NOT NULL,
            booking_date TEXT NOT NULL,
            booking_time TEXT NOT NULL,
            token INTEGER NOT NULL,
            status TEXT DEFAULT 'Waiting',
            payment_status TEXT DEFAULT 'Paid',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)

    # Doctor master table - controlled by Admin
    conn.execute("""
        CREATE TABLE IF NOT EXISTS doctors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            specialist TEXT NOT NULL,
            qualification TEXT DEFAULT '',
            experience TEXT DEFAULT '',
            room TEXT DEFAULT '',
            available_from TEXT NOT NULL,
            available_to TEXT NOT NULL,
            service_time INTEGER DEFAULT 10,
            active INTEGER DEFAULT 1
        )
    """)

    # Seed default doctors only when the doctor table is empty.
    doctor_count = conn.execute(
        "SELECT COUNT(*) AS c FROM doctors"
    ).fetchone()["c"]

    if doctor_count == 0:
        for doctor in DOCTORS:
            conn.execute("""
                INSERT INTO doctors
                (name, specialist, qualification, experience, room,
                 available_from, available_to, service_time, active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
            """, (
                doctor["name"],
                doctor["specialist"],
                "",
                "",
                "",
                "10:00",
                "17:00",
                doctor["service_time"]
            ))

    # Demo user
    existing_user = conn.execute(
        "SELECT id FROM users WHERE username = ?",
        ("krishna",)
    ).fetchone()

    if not existing_user:
        conn.execute("""
            INSERT INTO users
            (name, age, gender, username, password)
            VALUES (?, ?, ?, ?, ?)
        """, (
            "Krishna",
            20,
            "Female",
            "krishna",
            "1234"
        ))

    conn.commit()
    conn.close()


init_db()


# ============================================================
# LOGIN DECORATORS
# ============================================================

def login_required(function):

    @wraps(function)
    def wrapper(*args, **kwargs):

        if "user_id" not in session:
            return redirect(url_for("login"))

        return function(*args, **kwargs)

    return wrapper


def admin_required(function):

    @wraps(function)
    def wrapper(*args, **kwargs):

        if not session.get("admin"):
            return redirect(url_for("admin_login"))

        return function(*args, **kwargs)

    return wrapper


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def format_date(date_string):

    """
    Converts:
        YYYY-MM-DD

    Into:
        DD-MM-YYYY
    """

    try:
        return datetime.strptime(
            date_string,
            "%Y-%m-%d"
        ).strftime("%d-%m-%Y")

    except Exception:
        return date_string


def get_doctor(doctor_full):
    """Get an active doctor from the database.

    Accepts either:
    - full display value: Dr. Name - Specialist
    - doctor name: Dr. Name
    """
    conn = db()
    doctor = conn.execute("""
        SELECT *
        FROM doctors
        WHERE active = 1
        AND (
            name = ?
            OR (name || ' - ' || specialist) = ?
        )
        LIMIT 1
    """, (doctor_full, doctor_full)).fetchone()
    conn.close()

    return doctor


def get_all_doctors(active_only=True):
    conn = db()

    if active_only:
        doctors = conn.execute("""
            SELECT *
            FROM doctors
            WHERE active = 1
            ORDER BY name
        """).fetchall()
    else:
        doctors = conn.execute("""
            SELECT *
            FROM doctors
            ORDER BY active DESC, name
        """).fetchall()

    conn.close()
    return doctors


def make_time_slots(start_time, end_time, interval_minutes=30):
    """Create 30-minute appointment slots between two HH:MM times."""
    try:
        start = datetime.strptime(start_time, "%H:%M")
        end = datetime.strptime(end_time, "%H:%M")
    except ValueError:
        return []

    slots = []
    current = start

    while current < end:
        slots.append(current.strftime("%I:%M %p"))
        current += timedelta(minutes=interval_minutes)

    return slots


def get_next_token(conn):

    row = conn.execute("""
        SELECT MAX(token) AS max_token
        FROM bookings
    """).fetchone()

    if row["max_token"] is None:
        return 101

    return row["max_token"] + 1


# ============================================================
# AI WAITING TIME PREDICTION
# ============================================================

def predict_waiting_time(booking):

    """
    AI-style waiting-time prediction.

    Uses:
    - Number of people ahead
    - Doctor service time
    - Currently serving patients
    """

    conn = db()

    # --------------------------------------------------------
    # FIX 1:
    # SQLite placeholders now receive the correct values.
    # --------------------------------------------------------

    people_ahead = conn.execute("""
        SELECT COUNT(*) AS c
        FROM bookings
        WHERE booking_date = ?
        AND doctor = ?
        AND token < ?
        AND status IN ('Waiting', 'Serving')
    """, (
        booking["booking_date"],
        booking["doctor"],
        booking["token"]
    )).fetchone()["c"]

    # Currently serving patients
    serving = conn.execute("""
        SELECT COUNT(*) AS c
        FROM bookings
        WHERE booking_date = ?
        AND status = 'Serving'
    """, (
        booking["booking_date"],
    )).fetchone()["c"]

    conn.close()

    doctor = get_doctor(booking["doctor"])

    if doctor:
        service_minutes = doctor["service_time"]
    else:
        service_minutes = 10

    # AI-style prediction
    wait = (
        people_ahead * service_minutes
        + serving * 3
    )

    # Minimum wait
    wait = max(5, wait)

    return wait, people_ahead


# ============================================================
# HOME PAGE
# ============================================================

HOME_HTML = """
<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Smart Queue</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: linear-gradient(135deg, #0f172a, #1e3a8a);
    color: white;
    min-height: 100vh;
}

.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 7%;
}

.logo {
    font-size: 27px;
    font-weight: bold;
}

.nav-buttons a {
    text-decoration: none;
    color: white;
    padding: 10px 18px;
    border-radius: 8px;
    margin-left: 10px;
}

.login-btn {
    border: 1px solid white;
}

.register-btn {
    background: #2563eb;
}

.hero {
    min-height: 80vh;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 50px 8%;
    gap: 50px;
}

.hero-content {
    max-width: 650px;
}

.hero h1 {
    font-size: 60px;
    line-height: 1.1;
    margin-bottom: 20px;
}

.hero h1 span {
    color: #60a5fa;
}

.hero p {
    font-size: 20px;
    line-height: 1.7;
    color: #dbeafe;
}

.hero-buttons {
    margin-top: 30px;
}

.hero-buttons a {
    display: inline-block;
    padding: 15px 25px;
    text-decoration: none;
    border-radius: 10px;
    margin-right: 10px;
    font-weight: bold;
}

.primary {
    background: #2563eb;
    color: white;
}

.secondary {
    border: 1px solid white;
    color: white;
}

.queue-card {
    width: 330px;
    padding: 35px;
    background: rgba(255,255,255,0.12);
    border-radius: 25px;
    backdrop-filter: blur(15px);
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
}

.queue-card h2 {
    margin-bottom: 20px;
}

.queue-number {
    font-size: 65px;
    font-weight: bold;
    color: #60a5fa;
}

.features {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 20px;
    padding: 50px 8%;
}

.feature {
    background: rgba(255,255,255,0.08);
    padding: 30px;
    border-radius: 18px;
}

.feature h3 {
    margin-bottom: 10px;
}

.feature p {
    color: #dbeafe;
    line-height: 1.6;
}

@media(max-width:800px) {

    .hero {
        flex-direction: column;
        text-align: center;
    }

    .hero h1 {
        font-size: 42px;
    }

    .features {
        grid-template-columns: 1fr;
    }
}

</style>

</head>

<body>

<nav class="navbar">

    <div class="logo">
        🏥 Smart Queue
    </div>

    <div class="nav-buttons">

        <a href="/login" class="login-btn">
            Login
        </a>

        <a href="/register" class="register-btn">
            Register
        </a>

    </div>

</nav>


<section class="hero">

    <div class="hero-content">

        <h1>
            When Is
            <span>My Turn?</span>
        </h1>

        <p>
            Smart Queue is a digital token and queue
            management system that helps users book
            appointments, track their live queue and
            estimate their waiting time.
        </p>

        <div class="hero-buttons">

            <a href="/register" class="primary">
                Get Started
            </a>

            <a href="/admin-login" class="secondary">
                Admin Login
            </a>

        </div>

    </div>


    <div class="queue-card">

        <h2>
            🧑‍⚕️ Live Queue
        </h2>

        <p>
            Current Token
        </p>

        <div class="queue-number">
            101
        </div>

        <p>
            Smart AI Waiting Time Prediction
        </p>

    </div>

</section>


<section class="features">

    <div class="feature">

        <h3>
            🎟️ Digital Token
        </h3>

        <p>
            Book your token online and avoid
            standing in long physical queues.
        </p>

    </div>


    <div class="feature">

        <h3>
            🤖 AI Prediction
        </h3>

        <p>
            Get an estimated waiting time based
            on the current queue.
        </p>

    </div>


    <div class="feature">

        <h3>
            🔔 Live Queue
        </h3>

        <p>
            Track the queue and know when your
            turn is approaching.
        </p>

    </div>

</section>

</body>
</html>
"""


@app.route("/")
def home():
    return render_template_string(HOME_HTML)


# ============================================================
# REGISTER
# ============================================================

REGISTER_HTML = """
<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Register - Smart Queue</title>

<style>

body {
    margin: 0;
    min-height: 100vh;
    background: linear-gradient(135deg,#0f172a,#2563eb);
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: Arial;
}

.box {
    width: 420px;
    background: white;
    padding: 35px;
    border-radius: 20px;
    box-shadow: 0 20px 50px rgba(0,0,0,.3);
}

h1 {
    text-align: center;
    color: #1e3a8a;
}

input, select {
    width: 100%;
    padding: 13px;
    margin: 8px 0 15px;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-sizing: border-box;
}

button {
    width: 100%;
    padding: 14px;
    border: 0;
    border-radius: 8px;
    background: #2563eb;
    color: white;
    font-weight: bold;
    cursor: pointer;
}

a {
    display: block;
    text-align: center;
    margin-top: 18px;
    color: #2563eb;
    text-decoration: none;
}

.error {
    color: red;
    text-align: center;
}

</style>

</head>

<body>

<div class="box">

<h1>📝 Register</h1>

{% if error %}
<p class="error">{{ error }}</p>
{% endif %}

<form method="POST">

<input
    type="text"
    name="name"
    placeholder="Full Name"
    required
>

<input
    type="number"
    name="age"
    placeholder="Age"
    min="1"
    max="120"
    required
>

<select name="gender" required>

<option value="">
Select Gender
</option>

<option value="Male">
Male
</option>

<option value="Female">
Female
</option>

<option value="Other">
Other
</option>

</select>

<input
    type="text"
    name="username"
    placeholder="Username"
    required
>

<input
    type="password"
    name="password"
    placeholder="Password"
    required
>

<button type="submit">
Create Account
</button>

</form>

<a href="/login">
Already have an account? Login
</a>

</div>

</body>
</html>
"""


@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        name = request.form.get("name")
        age = request.form.get("age")
        gender = request.form.get("gender")
        username = request.form.get("username")
        password = request.form.get("password")

        conn = db()

        try:

            conn.execute("""
                INSERT INTO users
                (name, age, gender, username, password)
                VALUES (?, ?, ?, ?, ?)
            """, (
                name,
                age,
                gender,
                username,
                password
            ))

            conn.commit()
            conn.close()

            return redirect(url_for("login"))

        except sqlite3.IntegrityError:

            conn.close()

            return render_template_string(
                REGISTER_HTML,
                error="Username already exists."
            )

    return render_template_string(
        REGISTER_HTML,
        error=None
    )


# ============================================================
# LOGIN
# ============================================================

LOGIN_HTML = """
<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Login - Smart Queue</title>

<style>

body {
    margin: 0;
    min-height: 100vh;
    background: linear-gradient(135deg,#0f172a,#2563eb);
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: Arial;
}

.box {
    width: 400px;
    background: white;
    padding: 35px;
    border-radius: 20px;
}

h1 {
    text-align: center;
    color: #1e3a8a;
}

input {
    width: 100%;
    padding: 14px;
    margin: 10px 0;
    box-sizing: border-box;
    border: 1px solid #ddd;
    border-radius: 8px;
}

button {
    width: 100%;
    padding: 14px;
    border: none;
    border-radius: 8px;
    background: #2563eb;
    color: white;
    cursor: pointer;
    font-weight: bold;
}

.error {
    text-align: center;
    color: red;
}

.demo {
    background: #eff6ff;
    padding: 12px;
    border-radius: 8px;
    margin-top: 15px;
    color: #1e3a8a;
}

a {
    display: block;
    text-align: center;
    margin-top: 15px;
    color: #2563eb;
    text-decoration: none;
}

</style>

</head>

<body>

<div class="box">

<h1>
🔐 Smart Queue Login
</h1>

{% if error %}
<p class="error">{{ error }}</p>
{% endif %}

<form method="POST">

<input
    type="text"
    name="username"
    placeholder="Username"
    required
>

<input
    type="password"
    name="password"
    placeholder="Password"
    required
>

<button>
Login
</button>

</form>

<div class="demo">

<b>Demo Account</b><br><br>

Username: <b>krishna</b><br>
Password: <b>1234</b>

</div>

<a href="/register">
Create new account
</a>

<a href="/">
← Home
</a>

</div>

</body>

</html>
"""


@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form.get("username")
        password = request.form.get("password")

        conn = db()

        user = conn.execute("""
            SELECT *
            FROM users
            WHERE username = ?
            AND password = ?
        """, (
            username,
            password
        )).fetchone()

        conn.close()

        if user:

            session["user_id"] = user["id"]
            session["username"] = user["username"]

            return redirect(url_for("dashboard"))

        return render_template_string(
            LOGIN_HTML,
            error="Invalid username or password."
        )

    return render_template_string(
        LOGIN_HTML,
        error=None
    )


# ============================================================
# LOGOUT
# ============================================================

@app.route("/logout")
def logout():

    session.clear()

    return redirect(url_for("home"))


# ============================================================
# DASHBOARD
# ============================================================

DASHBOARD_HTML = """
<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Smart Queue Dashboard</title>

<style>

* {
    box-sizing: border-box;
    font-family: Arial;
}

body {
    margin: 0;
    background: #f1f5f9;
    color: #0f172a;
}

.navbar {
    background: #0f172a;
    color: white;
    padding: 18px 6%;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.logo {
    font-size: 24px;
    font-weight: bold;
}

.navbar a {
    color: white;
    text-decoration: none;
    margin-left: 15px;
}

.container {
    width: 92%;
    max-width: 1250px;
    margin: 30px auto;
}

.welcome {
    margin-bottom: 25px;
}

.welcome h1 {
    margin-bottom: 5px;
}

.grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px;
}

.card {
    background: white;
    border-radius: 18px;
    padding: 25px;
    box-shadow: 0 8px 30px rgba(0,0,0,.08);
}

.card h2 {
    margin-top: 0;
}

input, select {
    width: 100%;
    padding: 13px;
    margin: 7px 0 15px;
    border: 1px solid #ddd;
    border-radius: 8px;
}

button {
    padding: 13px 20px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
}

.book-btn {
    background: #2563eb;
    color: white;
    width: 100%;
}

.payment {
    background: #eff6ff;
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 15px;
}

.slot-container {
    display: grid;
    grid-template-columns: repeat(2,1fr);
    gap: 10px;
    margin-top: 15px;
}

.slot {
    padding: 15px;
    border-radius: 10px;
    text-align: center;
    cursor: pointer;
    border: 2px solid #2563eb;
    background: #dbeafe;
    color: #1e3a8a;
}

.slot:hover {
    background: #bfdbfe;
}

.slot.booked {
    background: #fecaca;
    border-color: #dc2626;
    color: #991b1b;
    cursor: not-allowed;
}

.slot.selected {
    background: #2563eb;
    color: white;
}

.my-booking {
    margin-top: 25px;
}

.booking-box {
    background: #f8fafc;
    border-left: 5px solid #2563eb;
    padding: 18px;
    border-radius: 8px;
    margin-bottom: 12px;
}

.token {
    font-size: 40px;
    font-weight: bold;
    color: #2563eb;
}

.wait {
    color: #059669;
    font-weight: bold;
}

.status {
    display: inline-block;
    padding: 5px 10px;
    border-radius: 20px;
    background: #dbeafe;
    color: #1e40af;
}

.queue-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}

.queue-table th,
.queue-table td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    text-align: left;
}

.no-booking {
    color: #64748b;
}

.alert {
    padding: 15px;
    background: #dcfce7;
    color: #166534;
    border-radius: 8px;
    margin-bottom: 20px;
}

@media(max-width:850px) {

    .grid {
        grid-template-columns: 1fr;
    }

    .slot-container {
        grid-template-columns: 1fr;
    }

}

</style>

</head>

<body>

<nav class="navbar">

<div class="logo">
🏥 Smart Queue
</div>

<div>
Welcome, {{ user["name"] }}

<a href="/logout">
Logout
</a>
</div>

</nav>


<div class="container">

<div class="welcome">

<h1>
👋 Welcome, {{ user["name"] }}
</h1>

<p>
Book your appointment and track your queue.
</p>

</div>


{% if message %}

<div class="alert">
{{ message }}
</div>

{% endif %}


<div class="grid">


<!-- BOOKING CARD -->

<div class="card">

<h2>
📅 Book Token
</h2>

<form method="POST"
      action="/book"
      id="bookingForm">

<label>
Select Doctor
</label>

<select name="doctor"
        id="doctor"
        required
        onchange="loadSlots()">

<option value="">
Select Doctor
</option>

{% for doctor in doctors %}

<option value="{{ doctor['name'] }} - {{ doctor['specialist'] }}">
{{ doctor["name"] }} -
{{ doctor["specialist"] }}
</option>

{% endfor %}

</select>


<label>
Select Date
</label>

<input
    type="date"
    name="booking_date"
    id="booking_date"
    min="{{ min_date }}"
    max="{{ max_date }}"
    required
    onchange="loadSlots()"
>


<label>
Select Time Slot
</label>

<input
    type="hidden"
    name="booking_time"
    id="booking_time"
    required
>

<div id="slots"
     class="slot-container">

<p>
Select doctor and date to see slots.
</p>

</div>


<div class="payment">

<b>
💳 Demo UPI Payment
</b>

<p>
Booking fee: ₹50
</p>

<label>

<input
    type="checkbox"
    id="payment"
    name="payment"
    value="paid"
    required
    style="width:auto;"
>

I confirm the demo payment of ₹50.

</label>

</div>


<button
    type="submit"
    class="book-btn">

🎟️ Confirm Booking

</button>

</form>

</div>


<!-- LIVE QUEUE -->

<div class="card">

<h2>
🔴 Live Queue
</h2>

<div id="queueInfo">

Loading queue...

</div>

</div>

</div>


<!-- MY BOOKINGS -->

<div class="card my-booking">

<h2>
🎫 My Bookings
</h2>

<div id="myBookings">

{% if bookings %}

{% for booking in bookings %}

<div class="booking-box">

<div>
Token
</div>

<div class="token">
#{{ booking["token"] }}
</div>

<p>
👨‍⚕️ <b>Doctor:</b>
{{ booking["doctor"] }}
</p>

<p>
🩺 <b>Specialist:</b>
{{ booking["specialist"] }}
</p>

<p>
📅 <b>Date:</b>
{{ format_date(booking["booking_date"]) }}
</p>

<p>
⏰ <b>Time:</b>
{{ booking["booking_time"] }}
</p>

<p>
Status:
<span class="status">
{{ booking["status"] }}
</span>
</p>

<p>
🤖 Estimated Waiting Time:
<span class="wait">
{{ booking["wait"] }} minutes
</span>
</p>

<p>
👥 People Ahead:
<b>{{ booking["ahead"] }}</b>
</p>

</div>

{% endfor %}

{% else %}

<p class="no-booking">
You have no bookings yet.
</p>

{% endif %}

</div>

</div>

</div>


<script>

function loadSlots() {

    const doctor =
        document.getElementById("doctor").value;

    const date =
        document.getElementById("booking_date").value;

    const slots =
        document.getElementById("slots");

    if (!doctor || !date) {

        slots.innerHTML =
            "<p>Select doctor and date.</p>";

        return;
    }

    fetch(
        "/api/slots?doctor="
        + encodeURIComponent(doctor)
        + "&date="
        + encodeURIComponent(date)
    )

    .then(response => response.json())

    .then(data => {

        slots.innerHTML = "";

        data.slots.forEach(slot => {

            const div =
                document.createElement("div");

            div.className = "slot";

            if (slot.booked) {

                div.classList.add("booked");

                div.innerHTML =
                    "🔴 " + slot.time
                    + "<br>Booked";

            } else {

                div.innerHTML =
                    "🔵 " + slot.time
                    + "<br>Available";

                div.onclick = function() {

                    document
                        .querySelectorAll(".slot")
                        .forEach(s =>
                            s.classList.remove("selected")
                        );

                    div.classList.add("selected");

                    document
                        .getElementById("booking_time")
                        .value = slot.time;
                };
            }

            slots.appendChild(div);

        });

    });

}


function loadQueue() {

    fetch("/api/queue")

    .then(response => response.json())

    .then(data => {

        const box =
            document.getElementById("queueInfo");

        if (!data.current) {

            box.innerHTML = `
                <p>No patient is currently being served.</p>
            `;

            return;
        }

        box.innerHTML = `

            <h3>
                Currently Serving
            </h3>

            <div class="token">
                #${data.current.token}
            </div>

            <p>
                Doctor:
                <b>${data.current.doctor}</b>
            </p>

            <p>
                Date:
                <b>${data.current.display_date}</b>
            </p>

            <p>
                Status:
                <span class="status">
                    ${data.current.status}
                </span>
            </p>

            <hr>

            <p>
                Waiting Patients:
                <b>${data.waiting}</b>
            </p>

        `;

    });

}


loadQueue();

setInterval(loadQueue, 10000);

</script>

</body>
</html>
"""


@app.route("/dashboard")
@login_required
def dashboard():

    conn = db()

    user = conn.execute("""
        SELECT *
        FROM users
        WHERE id = ?
    """, (
        session["user_id"],
    )).fetchone()

    bookings = conn.execute("""
        SELECT *
        FROM bookings
        WHERE user_id = ?
        ORDER BY id DESC
    """, (
        session["user_id"],
    )).fetchall()

    conn.close()

    booking_list = []

    for booking in bookings:

        wait, ahead = predict_waiting_time(booking)

        item = dict(booking)

        item["wait"] = wait
        item["ahead"] = ahead

        booking_list.append(item)

    today = date.today()

    min_date = today.strftime("%Y-%m-%d")

    max_date = (
        today + timedelta(days=90)
    ).strftime("%Y-%m-%d")

    return render_template_string(
        DASHBOARD_HTML,
        user=user,
        doctors=get_all_doctors(),
        bookings=booking_list,
        format_date=format_date,
        min_date=min_date,
        max_date=max_date,
        message=request.args.get("message")
    )


# ============================================================
# API - AVAILABLE SLOTS
# ============================================================

@app.route("/api/slots")
@login_required
def api_slots():

    doctor = request.args.get("doctor")
    booking_date = request.args.get("date")

    conn = db()

    booked = conn.execute("""
        SELECT booking_time
        FROM bookings
        WHERE doctor = ?
        AND booking_date = ?
        AND status != 'Cancelled'
    """, (
        doctor,
        booking_date
    )).fetchall()

    conn.close()

    booked_times = [
        row["booking_time"]
        for row in booked
    ]

    doctor_info = get_doctor(doctor)

    if not doctor_info:
        return jsonify({
            "slots": [],
            "error": "Doctor not found or inactive."
        })

    time_slots = make_time_slots(
        doctor_info["available_from"],
        doctor_info["available_to"],
        30
    )

    result = []

    for slot in time_slots:
        result.append({
            "time": slot,
            "booked": slot in booked_times
        })

    return jsonify({
        "slots": result,
        "doctor": {
            "name": doctor_info["name"],
            "specialist": doctor_info["specialist"],
            "qualification": doctor_info["qualification"],
            "experience": doctor_info["experience"],
            "room": doctor_info["room"],
            "available_from": doctor_info["available_from"],
            "available_to": doctor_info["available_to"]
        }
    })


# ============================================================
# BOOK TOKEN
# ============================================================

@app.route("/book", methods=["POST"])
@login_required
def book():

    doctor = request.form.get("doctor")
    booking_date = request.form.get("booking_date")
    booking_time = request.form.get("booking_time")
    payment = request.form.get("payment")

    # --------------------------------------------------------
    # Basic validation
    # --------------------------------------------------------

    if not doctor or not booking_date or not booking_time:

        return redirect(
            url_for(
                "dashboard",
                message="Please select doctor, date and time."
            )
        )

    if payment != "paid":

        return redirect(
            url_for(
                "dashboard",
                message="Please confirm the demo payment."
            )
        )

    # --------------------------------------------------------
    # Validate date range
    # --------------------------------------------------------

    try:

        selected_date = datetime.strptime(
            booking_date,
            "%Y-%m-%d"
        ).date()

    except ValueError:

        return redirect(
            url_for(
                "dashboard",
                message="Invalid date."
            )
        )

    today = date.today()

    if selected_date < today:

        return redirect(
            url_for(
                "dashboard",
                message="Past dates cannot be booked."
            )
        )

    if selected_date > today + timedelta(days=90):

        return redirect(
            url_for(
                "dashboard",
                message="You can book only within 3 months."
            )
        )

    # --------------------------------------------------------
    # Doctor validation
    # --------------------------------------------------------

    doctor_info = get_doctor(doctor)

    if not doctor_info:

        return redirect(
            url_for(
                "dashboard",
                message="Invalid doctor."
            )
        )

    # --------------------------------------------------------
    # User information
    # --------------------------------------------------------

    conn = db()

    user = conn.execute("""
        SELECT *
        FROM users
        WHERE id = ?
    """, (
        session["user_id"],
    )).fetchone()

    # --------------------------------------------------------
    # Check if slot is already booked
    # --------------------------------------------------------

    existing = conn.execute("""
        SELECT id
        FROM bookings
        WHERE doctor = ?
        AND booking_date = ?
        AND booking_time = ?
        AND status != 'Cancelled'
    """, (
        doctor,
        booking_date,
        booking_time
    )).fetchone()

    if existing:

        conn.close()

        return redirect(
            url_for(
                "dashboard",
                message="This slot is already booked."
            )
        )

    # --------------------------------------------------------
    # Generate token
    # --------------------------------------------------------

    token = get_next_token(conn)

    # --------------------------------------------------------
    # INSERT BOOKING
    # --------------------------------------------------------

    conn.execute("""
        INSERT INTO bookings
        (
            user_id,
            name,
            age,
            gender,
            doctor,
            specialist,
            booking_date,
            booking_time,
            token,
            status,
            payment_status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        user["id"],
        user["name"],
        user["age"],
        user["gender"],
        doctor_info["name"],
        doctor_info["specialist"],
        booking_date,
        booking_time,
        token,
        "Waiting",
        "Paid"
    ))

    conn.commit()

    # --------------------------------------------------------
    # IMPORTANT:
    # Get booking BEFORE closing connection.
    # --------------------------------------------------------

    booking = conn.execute("""
        SELECT *
        FROM bookings
        WHERE id = last_insert_rowid()
    """).fetchone()

    conn.close()

    # --------------------------------------------------------
    # AI waiting prediction
    # --------------------------------------------------------

    wait, ahead = predict_waiting_time(booking)

    # --------------------------------------------------------
    # Redirect to dashboard
    # --------------------------------------------------------

    message = (
        f"Booking successful! "
        f"Token #{token}. "
        f"Estimated waiting time: {wait} minutes."
    )

    return redirect(
        url_for(
            "dashboard",
            message=message
        )
    )


# ============================================================
# LIVE QUEUE API
# ============================================================

@app.route("/api/queue")
@login_required
def api_queue():

    today = date.today().strftime("%Y-%m-%d")

    conn = db()

    current = conn.execute("""
        SELECT *
        FROM bookings
        WHERE booking_date = ?
        AND status = 'Serving'
        ORDER BY token
        LIMIT 1
    """, (
        today,
    )).fetchone()

    waiting = conn.execute("""
        SELECT COUNT(*) AS c
        FROM bookings
        WHERE booking_date = ?
        AND status = 'Waiting'
    """, (
        today,
    )).fetchone()["c"]

    conn.close()

    current_data = None

    if current:

        current_data = {
            "token": current["token"],
            "doctor": current["doctor"],
            "specialist": current["specialist"],
            "status": current["status"],
            "display_date": format_date(
                current["booking_date"]
            )
        }

    return jsonify({
        "current": current_data,
        "waiting": waiting
    })


# ============================================================
# ADMIN LOGIN
# ============================================================

ADMIN_LOGIN_HTML = """
<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Admin Login</title>

<style>

body {
    margin: 0;
    min-height: 100vh;
    background: linear-gradient(135deg,#111827,#7c3aed);
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: Arial;
}

.box {
    width: 400px;
    background: white;
    padding: 35px;
    border-radius: 20px;
}

h1 {
    text-align: center;
}

input {
    width: 100%;
    padding: 14px;
    margin: 10px 0;
    box-sizing: border-box;
    border-radius: 8px;
    border: 1px solid #ddd;
}

button {
    width: 100%;
    padding: 14px;
    border: none;
    background: #7c3aed;
    color: white;
    border-radius: 8px;
    font-weight: bold;
}

.error {
    color: red;
    text-align: center;
}

.demo {
    margin-top: 20px;
    padding: 15px;
    background: #f3e8ff;
    border-radius: 8px;
}

a {
    display: block;
    text-align: center;
    margin-top: 15px;
    text-decoration: none;
    color: #7c3aed;
}

</style>

</head>

<body>

<div class="box">

<h1>
🛡️ Admin Login
</h1>

{% if error %}

<p class="error">
{{ error }}
</p>

{% endif %}

<form method="POST">

<input
    name="username"
    placeholder="Admin Username"
    required
>

<input
    type="password"
    name="password"
    placeholder="Admin Password"
    required
>

<button>
Login
</button>

</form>

<div class="demo">

<b>Demo Admin</b>

<br><br>

Username:
<b>admin</b>

<br>

Password:
<b>admin123</b>

</div>

<a href="/">
← Home
</a>

</div>

</body>

</html>
"""


@app.route("/admin-login", methods=["GET", "POST"])
def admin_login():

    if request.method == "POST":

        username = request.form.get("username")
        password = request.form.get("password")

        if username == "admin" and password == "admin123":

            session["admin"] = True

            return redirect(
                url_for("admin")
            )

        return render_template_string(
            ADMIN_LOGIN_HTML,
            error="Invalid admin credentials."
        )

    return render_template_string(
        ADMIN_LOGIN_HTML,
        error=None
    )


# ============================================================
# ADMIN LOGOUT
# ============================================================

@app.route("/admin-logout")
def admin_logout():

    session.pop("admin", None)

    return redirect(
        url_for("admin_login")
    )


# ============================================================
# ADMIN DASHBOARD
# ============================================================

ADMIN_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Smart Queue Admin</title>
<style>
*{box-sizing:border-box;font-family:Arial}
body{margin:0;background:#f1f5f9;color:#0f172a}
.navbar{background:#111827;color:white;padding:18px 5%;display:flex;justify-content:space-between;align-items:center}
.logo{font-size:24px;font-weight:bold}
.navbar a{color:white;text-decoration:none}
.container{width:94%;max-width:1450px;margin:30px auto}
h1,h2{margin-top:0}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:18px}
.stat,.card,.doctor-card{background:white;border-radius:16px;padding:22px;box-shadow:0 5px 20px rgba(0,0,0,.07)}
.stat h3{margin:0;color:#64748b}
.stat p{font-size:34px;font-weight:bold;color:#2563eb;margin:10px 0 0}
.card{margin-top:22px}
.form-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
input,select{width:100%;padding:12px;border:1px solid #d1d5db;border-radius:8px;margin-top:6px}
label{font-weight:bold;font-size:14px}
button{padding:11px 16px;border:0;border-radius:8px;color:white;cursor:pointer;font-weight:bold}
.primary{background:#2563eb}.green{background:#059669}.red{background:#dc2626}.purple{background:#7c3aed}.gray{background:#64748b}
.doctor-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-top:15px}
.doctor-card h3{margin:0 0 5px;color:#1e3a8a}
.doctor-meta{color:#64748b;font-size:14px;line-height:1.6}
.mini-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:15px 0}
.mini{background:#f8fafc;padding:10px;border-radius:8px;text-align:center}
.mini b{display:block;font-size:22px;color:#2563eb}
.buttons{display:flex;gap:8px;flex-wrap:wrap}
.queue-box{margin-top:12px;padding:12px;background:#f8fafc;border-radius:10px}
table{width:100%;border-collapse:collapse;margin-top:12px}
th,td{padding:10px;border-bottom:1px solid #e5e7eb;text-align:left}
.waiting{color:#2563eb;font-weight:bold}.serving{color:#d97706;font-weight:bold}.completed{color:#059669;font-weight:bold}
.notice{padding:12px;background:#ecfdf5;color:#166534;border-radius:8px;margin-bottom:15px;display:none}
@media(max-width:1000px){.doctor-grid{grid-template-columns:1fr 1fr}.form-grid{grid-template-columns:1fr 1fr}}
@media(max-width:700px){.grid,.doctor-grid,.form-grid{grid-template-columns:1fr}.mini-stats{grid-template-columns:repeat(2,1fr)}}
</style>
</head>
<body>
<nav class="navbar">
<div class="logo">🛡️ Smart Queue Admin</div>
<a href="/admin-logout">Logout</a>
</nav>

<div class="container">
<h1>Admin Dashboard</h1>
<div id="notice" class="notice"></div>

<div class="grid">
<div class="stat"><h3>Total Bookings</h3><p id="total">0</p></div>
<div class="stat"><h3>Waiting</h3><p id="waiting">0</p></div>
<div class="stat"><h3>Serving</h3><p id="serving">0</p></div>
<div class="stat"><h3>Completed</h3><p id="completed">0</p></div>
</div>

<div class="card">
<h2>👨‍⚕️ Doctor Management</h2>
<p>Add a doctor or update the doctor's complete details and available timings.</p>

<form id="doctorForm">
<input type="hidden" id="doctor_id">

<div class="form-grid">
<div><label>Doctor Name</label><input id="doctor_name" required placeholder="Dr. Name"></div>
<div><label>Specialist</label><input id="specialist" required placeholder="Cardiologist"></div>
<div><label>Qualification</label><input id="qualification" placeholder="MBBS, MD"></div>
<div><label>Experience</label><input id="experience" placeholder="10 years"></div>
<div><label>Room / Counter</label><input id="room" placeholder="Room 101"></div>
<div><label>Service Time / Patient (minutes)</label><input id="service_time" type="number" min="1" value="10" required></div>
<div><label>Available From</label><input id="available_from" type="time" value="10:00" required></div>
<div><label>Available To</label><input id="available_to" type="time" value="17:00" required></div>
</div>

<br>
<div class="buttons">
<button type="submit" class="primary">💾 Save Doctor</button>
<button type="button" class="gray" onclick="resetDoctorForm()">Clear</button>
</div>
</form>
</div>

<div class="card">
<h2>📊 Doctor-wise Dashboards</h2>
<div id="doctorDashboards" class="doctor-grid"></div>
</div>

<div class="card">
<h2>🎟️ Queue Management</h2>
<label>Select Doctor</label>
<select id="queueDoctor" onchange="loadDoctorQueue()"></select>

<div id="currentBox" class="queue-box">Select a doctor to manage the queue.</div>

<div class="buttons" style="margin-top:12px">
<button class="primary" onclick="callNext()">▶️ Call Next Patient</button>
<button class="green" onclick="completeCurrent()">✅ Complete Current</button>
</div>
</div>

<div class="card">
<h2>📋 All Bookings</h2>
<div style="overflow-x:auto">
<table>
<thead><tr>
<th>Token</th><th>Patient</th><th>Doctor</th><th>Specialist</th>
<th>Date</th><th>Time</th><th>Status</th><th>Payment</th>
</tr></thead>
<tbody id="bookings"></tbody>
</table>
</div>
</div>
</div>

<script>
let doctorsData=[];

function showNotice(message){
    const n=document.getElementById("notice");
    n.innerText=message;
    n.style.display="block";
    setTimeout(()=>n.style.display="none",3000);
}

function resetDoctorForm(){
    document.getElementById("doctorForm").reset();
    document.getElementById("doctor_id").value="";
    document.getElementById("service_time").value=10;
    document.getElementById("available_from").value="10:00";
    document.getElementById("available_to").value="17:00";
}

function editDoctor(d){
    document.getElementById("doctor_id").value=d.id;
    document.getElementById("doctor_name").value=d.name;
    document.getElementById("specialist").value=d.specialist;
    document.getElementById("qualification").value=d.qualification || "";
    document.getElementById("experience").value=d.experience || "";
    document.getElementById("room").value=d.room || "";
    document.getElementById("service_time").value=d.service_time;
    document.getElementById("available_from").value=d.available_from;
    document.getElementById("available_to").value=d.available_to;
    window.scrollTo({top:250,behavior:"smooth"});
}

function loadDoctors(){
    fetch("/api/admin/doctors")
    .then(r=>r.json())
    .then(data=>{
        doctorsData=data.doctors;
        const select=document.getElementById("queueDoctor");
        select.innerHTML='<option value="">Select Doctor</option>';
        data.doctors.filter(d=>d.active).forEach(d=>{
            select.innerHTML += `<option value="${d.id}">${d.name} - ${d.specialist}</option>`;
        });

        const box=document.getElementById("doctorDashboards");
        box.innerHTML="";
        data.doctors.filter(d=>d.active).forEach(d=>{
            const c=data.counts[d.id] || {total:0,waiting:0,serving:0,completed:0};
            box.innerHTML += `
            <div class="doctor-card">
                <h3>👨‍⚕️ ${d.name}</h3>
                <div class="doctor-meta">
                    <b>${d.specialist}</b><br>
                    ${d.qualification ? "🎓 "+d.qualification+"<br>" : ""}
                    ${d.experience ? "💼 "+d.experience+"<br>" : ""}
                    ${d.room ? "🚪 "+d.room+"<br>" : ""}
                    ⏰ ${d.available_from} - ${d.available_to}<br>
                    ⏱️ ${d.service_time} min/patient
                </div>
                <div class="mini-stats">
                    <div class="mini"><small>Total</small><b>${c.total}</b></div>
                    <div class="mini"><small>Waiting</small><b>${c.waiting}</b></div>
                    <div class="mini"><small>Serving</small><b>${c.serving}</b></div>
                    <div class="mini"><small>Completed</small><b>${c.completed}</b></div>
                </div>
                <div class="buttons">
                    <button class="purple" onclick='editDoctor(${JSON.stringify(d)})'>✏️ Edit</button>
                    <button class="red" onclick="deleteDoctor(${d.id})">🗑️ Remove</button>
                </div>
            </div>`;
        });
    });
}

document.getElementById("doctorForm").addEventListener("submit",function(e){
    e.preventDefault();

    const payload={
        id:document.getElementById("doctor_id").value,
        name:document.getElementById("doctor_name").value,
        specialist:document.getElementById("specialist").value,
        qualification:document.getElementById("qualification").value,
        experience:document.getElementById("experience").value,
        room:document.getElementById("room").value,
        service_time:document.getElementById("service_time").value,
        available_from:document.getElementById("available_from").value,
        available_to:document.getElementById("available_to").value
    };

    fetch("/api/admin/doctors/save",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(payload)
    })
    .then(r=>r.json())
    .then(data=>{
        showNotice(data.message);
        if(data.success){
            resetDoctorForm();
            loadDoctors();
            loadBookings();
        }
    });
});

function deleteDoctor(id){
    if(!confirm("Remove this doctor from new bookings? Existing bookings will remain.")) return;

    fetch("/api/admin/doctors/delete/"+id,{method:"POST"})
    .then(r=>r.json())
    .then(data=>{
        showNotice(data.message);
        loadDoctors();
        loadBookings();
    });
}

function loadDoctorQueue(){
    const doctorId=document.getElementById("queueDoctor").value;
    if(!doctorId){
        document.getElementById("currentBox").innerText="Select a doctor to manage the queue.";
        return;
    }

    fetch("/api/admin/doctor-queue/"+doctorId)
    .then(r=>r.json())
    .then(data=>{
        if(data.current){
            document.getElementById("currentBox").innerHTML=
                `<b>Currently Serving:</b> Token #${data.current.token} — ${data.current.name}<br>
                 <b>Date:</b> ${data.current.display_date} &nbsp;
                 <b>Time:</b> ${data.current.booking_time}<br>
                 <b>Waiting Patients:</b> ${data.waiting}`;
        }else{
            document.getElementById("currentBox").innerHTML=
                `<b>No patient currently serving.</b><br>Waiting Patients: ${data.waiting}`;
        }
    });
}

function callNext(){
    const doctorId=document.getElementById("queueDoctor").value;
    if(!doctorId){alert("Please select a doctor.");return;}

    fetch("/api/admin/next",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({doctor_id:doctorId})
    })
    .then(r=>r.json())
    .then(data=>{
        alert(data.message);
        loadDoctorQueue();
        loadBookings();
        loadDoctors();
    });
}

function completeCurrent(){
    const doctorId=document.getElementById("queueDoctor").value;
    if(!doctorId){alert("Please select a doctor.");return;}

    fetch("/api/admin/complete",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({doctor_id:doctorId})
    })
    .then(r=>r.json())
    .then(data=>{
        alert(data.message);
        loadDoctorQueue();
        loadBookings();
        loadDoctors();
    });
}

function loadBookings(){
    fetch("/api/admin/bookings")
    .then(r=>r.json())
    .then(data=>{
        document.getElementById("total").innerText=data.stats.total;
        document.getElementById("waiting").innerText=data.stats.waiting;
        document.getElementById("serving").innerText=data.stats.serving;
        document.getElementById("completed").innerText=data.stats.completed;

        const tbody=document.getElementById("bookings");
        tbody.innerHTML="";

        data.bookings.forEach(b=>{
            const cls=b.status==="Waiting"?"waiting":
                      b.status==="Serving"?"serving":
                      b.status==="Completed"?"completed":"";
            tbody.innerHTML += `
            <tr>
                <td><b>#${b.token}</b></td>
                <td>${b.name}</td>
                <td>${b.doctor}</td>
                <td>${b.specialist}</td>
                <td>${b.display_date}</td>
                <td>${b.booking_time}</td>
                <td class="${cls}">${b.status}</td>
                <td>${b.payment_status}</td>
            </tr>`;
        });
    });
}

loadDoctors();
loadBookings();
setInterval(()=>{loadDoctors();loadBookings();},5000);
</script>
</body>
</html>
"""


@app.route("/admin")
@admin_required
def admin():

    return render_template_string(
        ADMIN_HTML
    )


# ============================================================
# ADMIN - DOCTOR MANAGEMENT
# ============================================================

@app.route("/api/admin/doctors")
@admin_required
def admin_doctors():

    conn = db()

    doctors = conn.execute("""
        SELECT *
        FROM doctors
        ORDER BY active DESC, name
    """).fetchall()

    counts = {}

    for doctor in doctors:
        row = conn.execute("""
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN status = 'Waiting' THEN 1 ELSE 0 END) AS waiting,
                SUM(CASE WHEN status = 'Serving' THEN 1 ELSE 0 END) AS serving,
                SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) AS completed
            FROM bookings
            WHERE doctor = ?
        """, (doctor["name"],)).fetchone()

        counts[str(doctor["id"])] = {
            "total": row["total"] or 0,
            "waiting": row["waiting"] or 0,
            "serving": row["serving"] or 0,
            "completed": row["completed"] or 0
        }

    doctor_data = [dict(d) for d in doctors]

    conn.close()

    return jsonify({
        "doctors": doctor_data,
        "counts": counts
    })


@app.route("/api/admin/doctors/save", methods=["POST"])
@admin_required
def admin_save_doctor():

    data = request.get_json() or {}

    name = (data.get("name") or "").strip()
    specialist = (data.get("specialist") or "").strip()
    qualification = (data.get("qualification") or "").strip()
    experience = (data.get("experience") or "").strip()
    room = (data.get("room") or "").strip()
    available_from = (data.get("available_from") or "").strip()
    available_to = (data.get("available_to") or "").strip()

    try:
        service_time = int(data.get("service_time") or 10)
    except ValueError:
        service_time = 10

    if not name or not specialist or not available_from or not available_to:
        return jsonify({
            "success": False,
            "message": "Please fill doctor name, specialist and timings."
        })

    try:
        start = datetime.strptime(available_from, "%H:%M")
        end = datetime.strptime(available_to, "%H:%M")
    except ValueError:
        return jsonify({
            "success": False,
            "message": "Invalid doctor timing."
        })

    if end <= start:
        return jsonify({
            "success": False,
            "message": "Available To must be later than Available From."
        })

    if service_time < 1:
        return jsonify({
            "success": False,
            "message": "Service time must be at least 1 minute."
        })

    conn = db()

    doctor_id = data.get("id")

    if doctor_id:
        existing = conn.execute("""
            SELECT id, name
            FROM doctors
            WHERE id = ?
        """, (doctor_id,)).fetchone()

        if not existing:
            conn.close()
            return jsonify({
                "success": False,
                "message": "Doctor not found."
            })

        old_name = existing["name"]

        conn.execute("""
            UPDATE doctors
            SET name = ?,
                specialist = ?,
                qualification = ?,
                experience = ?,
                room = ?,
                available_from = ?,
                available_to = ?,
                service_time = ?,
                active = 1
            WHERE id = ?
        """, (
            name, specialist, qualification, experience, room,
            available_from, available_to, service_time, doctor_id
        ))

        # Keep future/new bookings linked to the renamed doctor.
        # Existing completed history is also updated for consistency.
        if old_name != name:
            conn.execute("""
                UPDATE bookings
                SET doctor = ?, specialist = ?
                WHERE doctor = ?
            """, (name, specialist, old_name))

        message = "Doctor details updated successfully."

    else:
        conn.execute("""
            INSERT INTO doctors
            (name, specialist, qualification, experience, room,
             available_from, available_to, service_time, active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
        """, (
            name, specialist, qualification, experience, room,
            available_from, available_to, service_time
        ))

        message = "Doctor added successfully."

    conn.commit()
    conn.close()

    return jsonify({
        "success": True,
        "message": message
    })


@app.route("/api/admin/doctors/delete/<int:doctor_id>", methods=["POST"])
@admin_required
def admin_delete_doctor(doctor_id):

    conn = db()

    doctor = conn.execute("""
        SELECT name
        FROM doctors
        WHERE id = ?
    """, (doctor_id,)).fetchone()

    if not doctor:
        conn.close()
        return jsonify({
            "success": False,
            "message": "Doctor not found."
        })

    # Soft delete so old booking history is preserved.
    conn.execute("""
        UPDATE doctors
        SET active = 0
        WHERE id = ?
    """, (doctor_id,))

    conn.commit()
    conn.close()

    return jsonify({
        "success": True,
        "message": "Doctor removed from new bookings."
    })


@app.route("/api/admin/doctor-queue/<int:doctor_id>")
@admin_required
def admin_doctor_queue(doctor_id):

    today = date.today().strftime("%Y-%m-%d")

    conn = db()

    doctor = conn.execute("""
        SELECT *
        FROM doctors
        WHERE id = ?
    """, (doctor_id,)).fetchone()

    if not doctor:
        conn.close()
        return jsonify({
            "current": None,
            "waiting": 0,
            "error": "Doctor not found."
        })

    current = conn.execute("""
        SELECT *
        FROM bookings
        WHERE booking_date = ?
        AND doctor = ?
        AND status = 'Serving'
        ORDER BY token
        LIMIT 1
    """, (today, doctor["name"])).fetchone()

    waiting = conn.execute("""
        SELECT COUNT(*) AS c
        FROM bookings
        WHERE booking_date = ?
        AND doctor = ?
        AND status = 'Waiting'
    """, (today, doctor["name"])).fetchone()["c"]

    conn.close()

    current_data = None

    if current:
        current_data = {
            "token": current["token"],
            "name": current["name"],
            "display_date": format_date(current["booking_date"]),
            "booking_time": current["booking_time"],
            "status": current["status"]
        }

    return jsonify({
        "current": current_data,
        "waiting": waiting
    })


# ============================================================
# ADMIN BOOKINGS API
# ============================================================

@app.route("/api/admin/bookings")
@admin_required
def admin_bookings():

    today = date.today().strftime("%Y-%m-%d")

    conn = db()

    bookings = conn.execute("""
        SELECT *
        FROM bookings
        ORDER BY
            CASE status
                WHEN 'Serving' THEN 1
                WHEN 'Waiting' THEN 2
                WHEN 'Completed' THEN 3
                ELSE 4
            END,
            booking_date,
            token
    """).fetchall()

    total = conn.execute("""
        SELECT COUNT(*) AS c
        FROM bookings
    """).fetchone()["c"]

    waiting = conn.execute("""
        SELECT COUNT(*) AS c
        FROM bookings
        WHERE status = 'Waiting'
    """).fetchone()["c"]

    serving = conn.execute("""
        SELECT COUNT(*) AS c
        FROM bookings
        WHERE status = 'Serving'
    """).fetchone()["c"]

    completed = conn.execute("""
        SELECT COUNT(*) AS c
        FROM bookings
        WHERE status = 'Completed'
    """).fetchone()["c"]

    current = conn.execute("""
        SELECT *
        FROM bookings
        WHERE booking_date = ?
        AND status = 'Serving'
        ORDER BY token
        LIMIT 1
    """, (
        today,
    )).fetchone()

    conn.close()

    booking_data = []

    for booking in bookings:

        booking_data.append({
            "id": booking["id"],
            "token": booking["token"],
            "name": booking["name"],
            "doctor": booking["doctor"],
            "specialist": booking["specialist"],
            "display_date": format_date(
                booking["booking_date"]
            ),
            "booking_time": booking["booking_time"],
            "status": booking["status"],
            "payment_status": booking["payment_status"]
        })

    current_data = None

    if current:

        current_data = {
            "token": current["token"]
        }

    return jsonify({

        "bookings": booking_data,

        "stats": {
            "total": total,
            "waiting": waiting,
            "serving": serving,
            "completed": completed
        },

        "current": current_data

    })


# ============================================================
# ADMIN - CALL NEXT
# ============================================================

@app.route("/api/admin/next", methods=["POST"])
@admin_required
def admin_next():

    data = request.get_json() or {}
    doctor_id = data.get("doctor_id")

    if not doctor_id:
        return jsonify({"message": "Please select a doctor."})

    today = date.today().strftime("%Y-%m-%d")

    conn = db()

    doctor = conn.execute("""
        SELECT *
        FROM doctors
        WHERE id = ?
        AND active = 1
    """, (doctor_id,)).fetchone()

    if not doctor:
        conn.close()
        return jsonify({"message": "Doctor not found."})

    # Complete the currently serving patient for THIS doctor only.
    conn.execute("""
        UPDATE bookings
        SET status = 'Completed'
        WHERE booking_date = ?
        AND doctor = ?
        AND status = 'Serving'
    """, (today, doctor["name"]))

    # Find next waiting patient for THIS doctor only.
    next_patient = conn.execute("""
        SELECT *
        FROM bookings
        WHERE booking_date = ?
        AND doctor = ?
        AND status = 'Waiting'
        ORDER BY token
        LIMIT 1
    """, (today, doctor["name"])).fetchone()

    if not next_patient:
        conn.commit()
        conn.close()
        return jsonify({
            "message": f"No waiting patients for {doctor['name']}."
        })

    conn.execute("""
        UPDATE bookings
        SET status = 'Serving'
        WHERE id = ?
    """, (next_patient["id"],))

    conn.commit()
    conn.close()

    return jsonify({
        "message":
            f"{doctor['name']} is now serving Token #{next_patient['token']}."
    })


# ============================================================
# ADMIN - COMPLETE CURRENT
# ============================================================

@app.route("/api/admin/complete", methods=["POST"])
@admin_required
def admin_complete():

    data = request.get_json() or {}
    doctor_id = data.get("doctor_id")

    if not doctor_id:
        return jsonify({"message": "Please select a doctor."})

    today = date.today().strftime("%Y-%m-%d")

    conn = db()

    doctor = conn.execute("""
        SELECT *
        FROM doctors
        WHERE id = ?
        AND active = 1
    """, (doctor_id,)).fetchone()

    if not doctor:
        conn.close()
        return jsonify({"message": "Doctor not found."})

    current = conn.execute("""
        SELECT *
        FROM bookings
        WHERE booking_date = ?
        AND doctor = ?
        AND status = 'Serving'
        ORDER BY token
        LIMIT 1
    """, (today, doctor["name"])).fetchone()

    if not current:
        conn.close()
        return jsonify({
            "message": f"No patient is currently serving for {doctor['name']}."
        })

    conn.execute("""
        UPDATE bookings
        SET status = 'Completed'
        WHERE id = ?
    """, (current["id"],))

    conn.commit()
    conn.close()

    return jsonify({
        "message":
            f"Token #{current['token']} for {doctor['name']} completed."
    })


# ============================================================
# RUN APPLICATION
# ============================================================

if __name__ == "__main__":

    print()
    print("=" * 60)
    print("        SMART QUEUE - WHEN IS MY TURN?")
    print("=" * 60)
    print()
    print("User Login:")
    print("Username : krishna")
    print("Password : 1234")
    print()
    print("Admin Login:")
    print("Username : admin")
    print("Password : admin123")
    print()
    print("Website:")
    print("http://127.0.0.1:5000")
    print()
    print("=" * 60)
    print()

    app.run(
        debug=True,
        host="127.0.0.1",
        port=5000
    )